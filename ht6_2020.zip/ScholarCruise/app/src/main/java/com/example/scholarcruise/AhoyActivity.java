package com.example.scholarcruise;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.os.Bundle;

public class AhoyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ahoy);
    }

    public void a3(View view) {
        startActivity(new Intent(this, MainActivity.class));
    }
}