package com.example.scholar_cruise.ui.scholarships;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class ScholarshipsViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public ScholarshipsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is scholarships fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}
