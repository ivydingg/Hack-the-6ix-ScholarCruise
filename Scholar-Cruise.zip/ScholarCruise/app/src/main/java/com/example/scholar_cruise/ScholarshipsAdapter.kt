package com.example.scholar_cruise

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class ScholarshipsAdapter : RecyclerView.Adapter<ScholarshipsAdapter.ScholarshipsViewHolder>() {

    private var scholarships: List<Scholarship>? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ScholarshipsViewHolder(
            DataBindingUtil.inflate(
                    LayoutInflater.from(parent.context),
                    R.layout.card_view_scholarship,
                    parent,
                    false
            )
    )

    override fun getItemCount() = scholarships?.size ?: 0

    override fun onBindViewHolder(holder: ScholarshipsViewHolder, position: Int) {
        scholarships?.let {
            holder.binding.scholarships = it[position]
            holder.binding.executePendingBindings()
        }
    }

    fun setScholarships(scholarships: List<Scholarship>) {
        this.scholarships = scholarships
        notifyDataSetChanged()
    }

    inner class ScholarshipsViewHolder(val binding: CardViewScholarshipBinding) :
            RecyclerView.ViewHolder(binding.root)

}