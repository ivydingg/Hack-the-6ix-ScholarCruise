package com.example.scholar_cruise

data class Scholarship(
        val value: Int,
        val start: String,
        val end: String,
        val eligibility: String,
        val details: String
)