package com.example.scholar_cruise

import android.telecom.Call

interface TinderAPI {

    @GET("profiles")
    fun getProfiles(): Call<List<Scholarship>>

    companion object {
        operator fun invoke(): TinderAPI {
            return Retrofit.Builder()
                    .baseUrl("https://api.simplifiedcoding.in/course-apis/tinder/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
                    .create(TinderAPI::class.java)
        }
    }
}